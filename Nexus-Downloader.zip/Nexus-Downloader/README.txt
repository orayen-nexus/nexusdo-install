Nexus Downloader - v2.4
1. Click Nexus-Downloader-Setup (.exe)
2. Allow installation from unknown sources.
3. Wait for installing.
4. Complete and enjoy!